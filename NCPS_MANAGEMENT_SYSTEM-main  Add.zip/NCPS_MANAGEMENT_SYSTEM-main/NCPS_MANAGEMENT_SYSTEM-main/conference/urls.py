from django.urls import path, include
from . import views

urlpatterns = [
    # Public
    path("", views.home, name="home"),
    path("venue-info/", views.venue_info, name="venue_info"),
    path("schedule/", views.schedule, name="schedule"),
    path("login/", views.user_login, name="login"),
    path("logout/", views.user_logout, name="logout"),
    path("register/", views.register, name="register"),

    # User dashboard
    path("dashboard/", views.dashboard, name="dashboard"),
    path("abstract-submission/", views.abstract_submission, name="abstract_submission"),
    path("submit-abstract/", views.abstract_submission, name="submit_abstract"),

    # ✅ REVISION UPLOAD (THIS WAS MISSING AT RUNTIME)
    path(
        "abstract/<int:pk>/upload-revision/",
        views.upload_revised_abstract,
        name="upload_revised_abstract",
    ),

    # Profile
    path("profile/", views.profile_view, name="profile"),
    path("profile/edit/", views.profile_edit, name="profile_edit"),

    # Admin
    path("admin-dashboard/", include("conference.admin_urls")),

    # User abstract detail (VIEW ABSTRACT)
path(
    "abstract/<int:pk>/",
    views.user_abstract_detail,
    name="user_abstract_detail",
),

]
