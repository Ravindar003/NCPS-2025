from django.db import models
from django.contrib.auth.models import User
import os
import time


# ==================================================
# PARTICIPANT
# ==================================================
class Participant(models.Model):

    SCIENTIFIC_THEMES = [
        ("climate_change", "Climate Change"),
        ("polar_biology", "Polar Biology"),
        ("glaciology", "Glaciology"),
        ("oceanography", "Oceanography"),
        ("atmospheric_science", "Atmospheric Science"),
        ("remote_sensing", "Remote Sensing"),
        ("polar_geology", "Polar Geology"),
        ("other", "Other"),
    ]

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="participant"
    )
    organization = models.CharField(max_length=255)
    designation = models.CharField(max_length=255)
    phone = models.CharField(max_length=30)

    scientific_theme = models.CharField(
        max_length=50,
        choices=SCIENTIFIC_THEMES,
        default="other"
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} ({self.organization})"


# ==================================================
# SCIENTIFIC THEME (ADMIN CONTROLLED)
# ==================================================
class ScientificTheme(models.Model):
    code = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=200)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


# ==================================================
# ABSTRACT SUBMISSION
# ==================================================
def submission_upload_path(instance, filename):
    ts = int(time.time())
    safe_name = filename.replace(" ", "_")
    return os.path.join(
        "abstracts",
        f"{instance.user.username}_{ts}_{safe_name}"
    )


class AbstractSubmission(models.Model):

    STATUS_CHOICES = [
        ("PENDING", "Pending"),
        ("RECOMMENDED", "Recommended"),
        ("REVISION", "Revision Required"),
        ("APPROVED", "Approved"),
        ("REJECTED", "Rejected"),
        ("RESUBMITTED", "Resubmitted"),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="abstracts"
    )

    title = models.CharField(max_length=255)

    abstract = models.TextField(
        blank=True,
        null=True
    )

    # ✅ OFFICIAL THEME (ADMIN CONTROL)
    theme = models.ForeignKey(
        ScientificTheme,
        on_delete=models.PROTECT,
        related_name="abstracts"
    )

    pdf_file = models.FileField(
        upload_to=submission_upload_path,
        blank=True,
        null=True
    )

    revised_submission = models.FileField(
        upload_to=submission_upload_path,
        blank=True,
        null=True
    )

    revised_uploaded_at = models.DateTimeField(
        blank=True,
        null=True
    )

    submitted_at = models.DateTimeField(auto_now_add=True)

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="PENDING"
    )

    admin_comments = models.TextField(
        blank=True,
        null=True
    )

    revision_due_date = models.DateField(
        blank=True,
        null=True
    )

    approved_by = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="approved_abstracts"
    )

    approved_at = models.DateTimeField(
        null=True,
        blank=True
    )


    class Meta:
        ordering = ["-submitted_at"]

    def __str__(self):
        return f"{self.title} — {self.user.username}"


# ==================================================
# THEME ADMIN
# ==================================================
class ThemeAdmin(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="theme_admin"
    )

    themes = models.ManyToManyField(
        ScientificTheme,
        related_name="theme_admins"
    )

    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.get_full_name() or self.user.username

class Notification(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="notifications"
    )
    abstract = models.ForeignKey(
        AbstractSubmission,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    title = models.CharField(max_length=255)
    message = models.TextField()

    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user.username} - {self.title}"


class AbstractReview(models.Model):

    REVIEW_CHOICES = [
        ("APPROVED", "Approve"),
        ("REVISION", "Revision Required"),
        ("REJECTED", "Reject"),
    ]

    abstract = models.ForeignKey(
        AbstractSubmission,
        on_delete=models.CASCADE,
        related_name="reviews"
    )
    reviewer = models.ForeignKey(
        ThemeAdmin,
        on_delete=models.CASCADE,
        related_name="assigned_reviews"
    )

    # ✅ NEW: who assigned the review
    assigned_by = models.ForeignKey(
        ThemeAdmin,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="sent_reviews"
    )

    status = models.CharField(
        max_length=20,
        choices=REVIEW_CHOICES,
        blank=True,
        null=True
    )

    comment = models.TextField(blank=True)
    is_submitted = models.BooleanField(default=False)

    submitted_at = models.DateTimeField(null=True, blank=True)
    edited_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("abstract", "reviewer")

# ==================================================
# ADMIN ACTION LOG
# ==================================================
class AdminActionLog(models.Model):
    ACTION_CHOICES = [
        ("CREATE", "Create"),
        ("UPDATE", "Update"),
        ("DELETE", "Delete"),
        ("APPROVED", "Approved"),
        ("REJECTED", "Rejected"),
        ("ASSIGN", "Assign Reviewer"),
        ("LOGIN", "Login"),
        ("LOGOUT", "Logout"),
        ("OTHER", "Other"),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="admin_logs"
    )

    action = models.CharField(
        max_length=20,
        choices=ACTION_CHOICES
    )

    object_type = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )

    object_id = models.PositiveIntegerField(
        blank=True,
        null=True
    )

    description = models.TextField(blank=True)

    ip_address = models.GenericIPAddressField(
        null=True,
        blank=True
    )


    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user.username if self.user else 'System'} - {self.action}"
