from django import forms
from .models import AbstractSubmission, ScientificTheme

class AbstractSubmissionForm(forms.ModelForm):

    theme = forms.ModelChoiceField(
        queryset=ScientificTheme.objects.all(),
        empty_label="Select Scientific Theme",
        widget=forms.Select(attrs={
            "class": "form-select"
        })
    )

    title = forms.CharField(
        widget=forms.TextInput(attrs={
            "class": "form-control",
            "placeholder": "Enter your abstract title"
        })
    )

    abstract = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            "id": "id_abstract",
            "class": "form-control"
        })
    )

    class Meta:
        model = AbstractSubmission
        fields = ["title", "theme", "abstract", "pdf_file"]
