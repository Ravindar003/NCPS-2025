from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.http import HttpResponseForbidden
from django.utils import timezone
from django.db.models import Count, Q, F

from .utils import get_client_ip
from .admin_views import _get_theme_filtered_abstracts
from .forms import AbstractSubmissionForm
from .models import (
    Participant,
    AbstractSubmission,
    ScientificTheme,
    AdminActionLog,
)

# -------------------------------------------------------------------
# HOME
# -------------------------------------------------------------------
def home(request):
    return render(request, "conference/home.html")


def venue_info(request):
    """Display venue information page"""
    return render(request, "conference/venue_info.html")


def schedule(request):
    """Display conference schedule page"""
    return render(request, "conference/schedule.html")


# -------------------------------------------------------------------
# AUTH
# -------------------------------------------------------------------
def user_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)

            # ✅ LOG ONLY AFTER SUCCESSFUL LOGIN
            AdminActionLog.objects.create(
                user=user,
                action="LOGIN",
                ip_address=get_client_ip(request),
                description="User logged in"
            )

            if user.is_superuser:
                return redirect("ncps_admin:dashboard")

            if hasattr(user, "theme_admin") and user.theme_admin.is_active:
                return redirect("ncps_admin:theme_dashboard")

            return redirect("dashboard")

        else:
            messages.error(request, "Invalid username or password.")

    return render(request, "conference/login.html")


def user_logout(request):
    AdminActionLog.objects.create(
        user=request.user if request.user.is_authenticated else None,
        action="LOGOUT",
        ip_address=get_client_ip(request),
        description="User logged out"
    )

    
    logout(request)
    return redirect("home")


# -------------------------------------------------------------------
# REGISTRATION
# -------------------------------------------------------------------
def register(request):
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        email = request.POST.get("email", "").strip()
        password1 = request.POST.get("password1")
        password2 = request.POST.get("password2")

        first_name = request.POST.get("first_name", "").strip()
        last_name = request.POST.get("last_name", "").strip()
        organization = request.POST.get("organization", "").strip()
        designation = request.POST.get("designation", "").strip()
        phone = request.POST.get("phone", "").strip()
        scientific_theme = request.POST.get("scientific_theme", "").strip()

        # ---------------- VALIDATIONS ----------------
        if not all([username, email, password1, scientific_theme]):
            messages.error(request, "All required fields must be filled.")
            return redirect("register")

        if password1 != password2:
            messages.error(request, "Passwords do not match.")
            return redirect("register")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return redirect("register")

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already exists.")
            return redirect("register")

        try:
            validate_email(email)
        except ValidationError:
            messages.error(request, "Enter a valid email address.")
            return redirect("register")

        if not phone.isdigit():
            messages.error(request, "Phone number must contain digits only.")
            return redirect("register")

        # ---------------- CREATE USER ----------------
        user = User.objects.create_user(
            username=username,
            email=email,
            password=password1,
            first_name=first_name,
            last_name=last_name,
        )

        # ---------------- CREATE PARTICIPANT ----------------
        Participant.objects.get_or_create(
            user=user,
            defaults={
                "organization": organization,
                "designation": designation,
                "phone": phone,
                "scientific_theme": scientific_theme,
            },
        )

        messages.success(request, "Registration successful. Please log in.")
        return redirect("login")

    return render(request, "conference/register.html")


# -------------------------------------------------------------------
# USER DASHBOARD
# -------------------------------------------------------------------
@login_required
def dashboard(request):
    if request.user.is_superuser:
        return redirect("ncps_admin:dashboard")

    abstracts = AbstractSubmission.objects.filter(
        user=request.user
    ).order_by("-submitted_at")

    notifications = request.user.notifications.all()[:5]

    context = {
        "submissions_count": abstracts.count(),
        "abstracts": abstracts,
        "abstract_deadline": "15 January 2025",
        "notifications": notifications,
        "notifications_count": request.user.notifications.filter(is_read=False).count(),
    }

    return render(request, "conference/dashboard.html", context)



# -------------------------------------------------------------------
# PROFILE
# -------------------------------------------------------------------
@login_required
def profile_view(request):
    return render(
        request,
        "conference/profile.html",
        {
            "user_obj": request.user,
            "participant": getattr(request.user, "participant", None),
        },
    )


@login_required
def profile_edit(request):
    user = request.user
    participant = getattr(user, "participant", None)

    if request.method == "POST":
        user.first_name = request.POST.get("first_name", "").strip()
        user.last_name = request.POST.get("last_name", "").strip()
        user.save()

        if participant:
            participant.organization = request.POST.get("organization", "").strip()
            participant.designation = request.POST.get("designation", "").strip()
            participant.phone = request.POST.get("phone", "").strip()
            participant.scientific_theme = request.POST.get(
                "scientific_theme", participant.scientific_theme
            )
            participant.save()

        messages.success(request, "Profile updated successfully.")
        return redirect("profile")

    return render(request, "conference/profile_edit.html")


# -------------------------------------------------------------------
# ABSTRACT SUBMISSION
# -------------------------------------------------------------------
@login_required
def abstract_submission(request):
    if request.method == "POST":
        form = AbstractSubmissionForm(request.POST, request.FILES)

        if not form.is_valid():
            messages.error(request, "Please correct the errors below.")
            return render(
                request,
                "conference/abstract_submission.html",
                {"form": form},
            )

        abstract = form.save(commit=False)
        abstract.user = request.user

        # server-side word count validation (only if PDF not uploaded)
        import re
        plain_text = re.sub(r"<[^>]*>", " ", abstract.abstract or "")
        wc = len(plain_text.split())

        if not abstract.pdf_file and (wc < 250 or wc > 500):
            messages.error(
                request,
                "Abstract must be 250–500 words or upload a PDF."
            )
            return render(
                request,
                "conference/abstract_submission.html",
                {"form": form},
            )

        abstract.save()
        messages.success(request, "Abstract submitted successfully.")
        return redirect("dashboard")

    form = AbstractSubmissionForm()
    return render(
        request,
        "conference/abstract_submission.html",
        {"form": form},
    )

# -------------------------------------------------------------------
# UPLOAD REVISED ABSTRACT
# -------------------------------------------------------------------
@login_required
def upload_revised_abstract(request, pk):
    abstract = get_object_or_404(
        AbstractSubmission,
        pk=pk,
        user=request.user
    )

    if abstract.status != "REVISION":
        messages.error(request, "Revision is not required for this abstract.")
        return redirect("dashboard")
    # ⏳ Deadline enforcement
    if abstract.revision_due_date and timezone.now().date() > abstract.revision_due_date:
        messages.error(request, "Revision deadline has passed.")
        return redirect("dashboard")


    if request.method == "POST":
        revised_file = request.FILES.get("revised_submission")
        revised_text = request.POST.get("revised_abstract", "").strip()

        # ❌ Neither provided
        if not revised_file and not revised_text:
            messages.error(
                request,
                "Please upload a revised PDF or update the abstract text."
            )
            return redirect(request.path)

        # ✅ Save revision
        if revised_file:
            abstract.revised_submission = revised_file

        if revised_text:
            abstract.abstract = revised_text


        abstract.revised_uploaded_at = timezone.now()
        abstract.status = "RESUBMITTED"
        abstract.admin_comments = None
        abstract.revision_due_date = None
        abstract.save()

        messages.success(request, "Revision submitted successfully.")
        return redirect("dashboard")

    return render(
        request,
        "conference/upload_revised_abstract.html",
        {"abstract": abstract}
    )
@staff_member_required
def theme_admin_participant_detail(request, pk):
    user = request.user

    if not hasattr(user, "theme_admin") or not user.theme_admin.is_active:
        return HttpResponseForbidden("Not authorized")

    participant = get_object_or_404(
        Participant.objects.select_related("user"),
        pk=pk
    )

    themes = user.theme_admin.themes.all()

    # ✅ SECURITY CHECK: participant must have abstracts in admin themes
    if not AbstractSubmission.objects.filter(
        user=participant.user,
        theme__in=themes
    ).exists():
        return HttpResponseForbidden("Not authorized for this participant")

    abstracts = AbstractSubmission.objects.filter(
        user=participant.user,
        theme__in=themes
    )

    return render(
        request,
        "admin/theme_registration_detail.html",
        {
            "registration": participant,
            "abstracts": abstracts,
        }
    )

@staff_member_required
def theme_participants(request):
    user = request.user

    if not hasattr(user, "theme_admin") or not user.theme_admin.is_active:
        return HttpResponseForbidden("Not authorized")

    themes = user.theme_admin.themes.all()

    participants = Participant.objects.filter(
        user__abstracts__theme__in=themes
    ).select_related("user").annotate(
        theme_abstract_count=Count(
            "user__abstracts",
            filter=Q(user__abstracts__theme__in=themes),
            distinct=True
        )
    ).distinct()


    return render(
        request,
        "admin/theme_participants.html",
        {"participants": participants}
    )

# -------------------------------------------------------------------
# USER ABSTRACT DETAIL (READ-ONLY)
# -------------------------------------------------------------------
@login_required
def user_abstract_detail(request, pk):
    abstract = get_object_or_404(
        AbstractSubmission,
        pk=pk,
        user=request.user   # 🔐 user can see ONLY their own abstract
    )

    return render(
        request,
        "conference/abstract_detail.html",
        {
            "abstract": abstract
        }
    )


